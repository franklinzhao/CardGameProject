package stocksmanager;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author franklinzhao
 */
public class StockList extends ArrayList<Stock> {

    private static StockList single_instance = null;

    /**
     * the default constructor
     */
    private StockList() {

    }

    /**
     *
     * @param file
     */
    private StockList(File file) throws FileNotFoundException {

        loadFromFile(file);
    }

    //static method to create instance of Singleton class 
    public static StockList getInstance(File file) throws FileNotFoundException {
        if (single_instance == null) {
            single_instance = new StockList(file);
        }

        return single_instance;
    }

    /**
     * This method accepts a stock symbol and searches the StockList elements
     * for a stock with the same symbol. If an item is found, that stock is
     * returned. If there is no item with that symbol, a null object (null) is
     * returned.
     *
     * @param symbol
     * @return Stock if found, otherwise return a null object
     */
    public Stock find(String symbol) {

        int temp = -1;
        boolean temp2 = false;

        for (Stock s : this) {
            if (s.getSymbol().equalsIgnoreCase(symbol)) {
                temp = this.indexOf(s);
                temp2 = true;
            }
        }

        if (temp2) {
            return this.get(temp);
        } else {
            return null;
        }

    }

    /**
     * The loadFromFile() method accepts a File object. The method read all the
     * records from the file and construct a CookieInventoryItem object for each
     * record. Each CookieInventoryItem object is added to the ArrayList inside
     * the StockList.
     *
     * @param file a File object as a input
     */
    public void loadFromFile(File file) throws FileNotFoundException {
        try {
            if (file.exists()) {
                Scanner scanner = new Scanner(file);
                // an even better way of catching all the possible values
                // that could represent a newline
                scanner.useDelimiter("\r\n|[\r\n\u2028\u2029\u0085]");
                while (scanner.hasNextLine()) {
                    String s = scanner.nextLine();
                    String[] fields = s.split("\\|");
                    //create a new stock object and add it to this 
                    //ArrayList 
                    //validate data before add them 
                    Boolean tf = isValidDouble(fields[3])
                            && isValidDouble(fields[4])
                            && isValidDouble(fields[5]);
                    if (tf) {
                        this.add(
                                new Stock(
                                        fields[0],
                                        fields[1],
                                        Sector.getSectorName(fields[2]),
                                        Double.parseDouble(fields[3]),
                                        Double.parseDouble(fields[4]),
                                        Double.parseDouble(fields[5]))
                        );
                    }

                }
                scanner.close();
            }
        } catch (IOException ex) {
            System.out.println("Error: file not found" + ex.getMessage());
        }

    }

    /**
     * Reference: This was retrieved from this web address.
     * https://stackoverflow.com/questions/41259861/check-for-a-valid-double-in-java
     *
     * @param s input a string
     * @return true if the input string is a double, otherwise return false
     */
    private boolean isValidDouble(String string) {

        boolean numeric = true;
        try {
            Double num = Double.parseDouble(string);
        } catch (NumberFormatException e) {
            numeric = false;
        }
        return numeric;
    }

    /**
     * The writeToFile() method accepts a File object. The method iterates
     * through all of the stock objects in the ArrayList and deconstructs them
     * into a delimited string that can be written to the file.
     *
     * @param file
     */
    public void writeToFile(File file) throws FileNotFoundException {
        try {
            if (file.exists()) {

                PrintWriter fileOut = new PrintWriter(file);
                if (fileOut != null && this != null) {
                    for (Stock s : this) {
                        fileOut.println(s.toFileString());//id|quantity
                    }
                }
                fileOut.close();
            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public StockList findStockByName(String name) {
        StockList temp = new StockList();

        
            for (Stock s : this) {
                Pattern p = Pattern.compile(name.trim().toLowerCase());
                Matcher m = p.matcher(s.getName().trim().toLowerCase());
                if (m.find()) {
                    temp.add(s);
                }
            }
        

        return temp;
    }

    public StockList findStockBySymbol(String symbol) {
        StockList temp = new StockList();

        for (Stock s : this) {
                Pattern p = Pattern.compile(symbol.trim().toLowerCase());
                Matcher m = p.matcher(s.getSymbol().trim().toLowerCase());
                if (m.find()) {
                    temp.add(s);
                }
            }

        return temp;

    }

    public String[] getStockNameList() {
        String[] stockNameList = new String[this.size()];

        for (int i = 0; i < this.size(); i++) {
            stockNameList[i] = this.get(i).getName();
        }
        return stockNameList;
    }
}
