/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stocksmanager;

/**
 *
 * @author franklinzhao
 */
public class Stock {
    private String symbol;
    private String name;
    private Sector sector;
    private double pe;
    private double pb;
    private double growthRate;
    
    public Stock(){}
    
    public Stock(String symbol) {
        this.symbol = symbol;
    }

    public Stock(String symbol, String name, Sector sector, double pe, 
            double pb, double growthRate) {
        this.symbol = symbol;
        this.name = name;
        this.sector = sector;
        this.pe = pe;
        this.pb = pb;
        this.growthRate = growthRate;
    }
    public void UpdateStock(String symbol, String name, Sector sector, double pe, 
            double pb, double growthRate) {
        this.symbol = symbol;
        this.name = name;
        this.sector = sector;
        this.pe = pe;
        this.pb = pb;
        this.growthRate = growthRate;
    }
    

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Sector getSector() {
        return sector;
    }

    public void setSector(Sector sector) {
        this.sector = sector;
    }

    public double getPe() {
        return pe;
    }

    public void setPe(double pe) {
        this.pe = pe;
    }

    public double getPb() {
        return pb;
    }

    public void setPb(double pb) {
        this.pb = pb;
    }

    public double getGrowthRate() {
        return growthRate;
    }

    public void setGrowthRate(double growthRate) {
        this.growthRate = growthRate;
    }
    
    public String toFileString(){
        return String.format("%s|%s|%s|%.2f|%.2f|%.2f", symbol,name,
                sector.name(),pe,pb,growthRate);
    }
    /**
     * 
     * @return a string of the symbol and name of the stock
     */
    @Override
    public String toString(){
        return String.format("%s | %s", symbol,name);
    }
    
}
