/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stocksmanager;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

/**
 *
 * @author franklinzhao
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private BorderPane bpMain;
    @FXML
    private VBox topVbox1, topVbox2, vbox1, vbox2;
    private String current = "vbox1";
    @FXML
    private ComboBox<Sector> cmbBoxSector;
    @FXML
    private ListView<Stock> lstView,lstResult;
    @FXML
    private TextField txtSymbol, txtName, txtPE, txtPB, txtGRate, txtSearch;
    @FXML
    private RadioButton rbtSymbol, rbtName;
    @FXML
    private Button btnSave, btnCancel, btnExit, btnAdd, btnEdit, btnSearch, btnDelete;
    @FXML
    private ToggleGroup grpSearchby;
    
    private int editClicked = 0;

    private File file = new File("stocks.txt");
    private StockList stockList;
    private int selectedStockIndex;
    private int selectedSectorIndex;
    ObservableList<Stock> obsStockList = FXCollections.observableArrayList();
    ObservableList<Sector> sectorList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //load the combo box with sector list
        sectorList.addAll(Sector.values());
        //for view,add, and edit sector infor.
        cmbBoxSector.setItems(sectorList);
        cmbBoxSector.getSelectionModel().select(0);

        //load the file to stockList
        try {
            if (file.exists()) {
                stockList = StockList.getInstance(file);

            }
        } catch (IOException ex) {
            System.out.println("Error: file not found" + ex.getMessage());
        }

        //put names into the ListView
        obsStockList.addAll(stockList);

        lstView.setItems(obsStockList);
        lstView.getSelectionModel().select(0);
        displayRecord(obsStockList.get(0));

        //Set up an event handler for the list box so that when an item is 
        //selected by the user, the item's data appears in the fields to the 
        //right.
        lstView.getSelectionModel().selectedItemProperty().addListener(new InvalidationListener() {

            @Override
            public void invalidated(Observable observable) {
                selectedStockIndex = lstView.getSelectionModel().getSelectedIndex();
                displayRecord(obsStockList.get(selectedStockIndex));
            }
        });
        //event listener for sector
        cmbBoxSector.getSelectionModel().selectedItemProperty().addListener(new InvalidationListener() {

            @Override
            public void invalidated(Observable observable) {
                selectedSectorIndex = cmbBoxSector.getSelectionModel().getSelectedIndex();

            }
        });

        //disable save and cancel buttons
        btnSave.setDisable(true);
        btnCancel.setDisable(true);

    }

    @FXML  //ActionEvent event
    public void swap() {
        if (current.equals("vbox1")) {
            bpMain.setTop(topVbox2);
            bpMain.setCenter(vbox2);
            current = "vbox2";
            //clear all contents of search screen
            txtSearch.clear();
            lstResult.getItems().clear();
            rbtSymbol.setSelected(true);

        } else {
            bpMain.setTop(topVbox1);
            bpMain.setCenter(vbox1);
            current = "vbox1";

        }
    }

    private void displayRecord(Stock stock) {
        //accepts a Wine object then display that Wine object's data in the 
        //corresponding fields on the UI.
        txtSymbol.setEditable(false);
        txtName.setEditable(false);
        //txtSector.setEditable(false);
        cmbBoxSector.setValue(stockList.get(selectedStockIndex).getSector());

        txtPE.setEditable(false);
        txtPB.setEditable(false);
        txtGRate.setEditable(false);
        txtSymbol.setText(String.format("%s", stock.getSymbol()));
        txtName.setText(stock.getName());
        //txtSector.setText(stock.getSector().getName());
        txtPE.setText(String.format("%.2f", stock.getPe()));
        txtPB.setText(String.format("%.2f", stock.getPb()));
        txtGRate.setText(String.format("%.2f", stock.getGrowthRate()));

        //set the color the grey
        txtSymbol.setStyle("-fx-background-color:#f3f3f3");
        txtName.setStyle("-fx-background-color:#f3f3f3");
        cmbBoxSector.setStyle("-fx-background-color:#f3f3f3");
        txtPE.setStyle("-fx-background-color:#f3f3f3");
        txtPB.setStyle("-fx-background-color:#f3f3f3");
        txtGRate.setStyle("-fx-background-color:#f3f3f3");
    }

    public void edit() {
        //set a mark when edit button clicked for distinct saving record
        editClicked = 1;
        txtSymbol.setEditable(false);
        txtName.setEditable(true);
        cmbBoxSector.setEditable(true);
        cmbBoxSector.setValue(stockList.get(selectedStockIndex).getSector());
        txtPE.setEditable(true);
        txtPB.setEditable(true);
        txtGRate.setEditable(true);
        setTxtFieldBcolorW();
        txtSymbol.setStyle("-fx-background-color:#f3f3f3");
        btnSave.setDisable(false);
        btnCancel.setDisable(false);

    }

    public void setTxtFieldBcolorW() {
        txtSymbol.setStyle("-fx-background-color:white");
        txtName.setStyle("-fx-background-color:white");
        cmbBoxSector.setStyle("-fx-background-color:white");
        txtPE.setStyle("-fx-background-color:white");
        txtPB.setStyle("-fx-background-color:white");
        txtGRate.setStyle("-fx-background-color:white");
    }

    //prepare add
    public void add() {
        //set a mark when add button clicked for distinct saving record
        editClicked = 0;
        txtSymbol.setEditable(false);
        txtName.setEditable(true);
        cmbBoxSector.setEditable(true);
        cmbBoxSector.setValue(stockList.get(selectedStockIndex).getSector());
        txtPE.setEditable(true);
        txtPB.setEditable(true);
        txtGRate.setEditable(true);
        setTxtFieldBcolorW();
        txtSymbol.setStyle("-fx-background-color:#f3f3f3");
        btnSave.setDisable(false);
        btnCancel.setDisable(false);

        txtSymbol.setEditable(true);
        txtSymbol.setStyle("-fx-background-color:white");
        txtSymbol.clear();
        txtName.clear();
        //cmbBoxSector.setValue(Sector.IT);
        txtPE.clear();
        txtPB.clear();
        txtGRate.clear();
        btnSave.setDisable(false);
        btnCancel.setDisable(false);
        btnEdit.setDisable(true);
        btnDelete.setDisable(true);
    }

    public void save() throws FileNotFoundException {
        //use symbol as the primary key, if it's edit, the symbol should not editable
        //if it's add, all are editable
        //1. for add new record
        if (editClicked == 0) {
            if (validInput()) {
                Stock s = new Stock(
                        txtSymbol.getText(),
                        txtName.getText(),
                        //cmbBoxSector.getValue(),
                        sectorList.get(selectedSectorIndex),
                        Double.parseDouble(txtPE.getText()),
                        Double.parseDouble(txtPB.getText()),
                        Double.parseDouble(txtGRate.getText())
                );

                stockList.add(s);
                obsStockList.clear();
                obsStockList.addAll(stockList);

                lstView.setItems(obsStockList);
                lstView.getSelectionModel().select(0);
                displayRecord(obsStockList.get(0));

                stockList.writeToFile(file);
            }
            updated();
        } else {
            //for edit record
            if (validInput()) {
                Stock editStock = stockList.get(selectedStockIndex);

                editStock.setSymbol(txtSymbol.getText());
                editStock.setName(txtName.getText());
                editStock.setSector(sectorList.get(selectedSectorIndex));
                editStock.setPe(Double.parseDouble(txtPE.getText()));
                editStock.setPe(Double.parseDouble(txtPB.getText()));
                editStock.setGrowthRate(Double.parseDouble(txtGRate.getText()));

                obsStockList.clear();
                obsStockList.addAll(stockList);

                lstView.setItems(obsStockList);
                lstView.getSelectionModel().select(0);
                displayRecord(obsStockList.get(0));

                stockList.writeToFile(file);
            }
            updated();
        }
        editClicked = 0;
        btnSave.setDisable(true);
        btnCancel.setDisable(true);
    }

    public void cancel() {
        editClicked = 0;
        displayRecord(stockList.get(selectedStockIndex));
        btnSave.setDisable(true);
        btnCancel.setDisable(true);
        btnEdit.setDisable(false);
    }

    public void delete() throws FileNotFoundException {
        editClicked = 0;
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(" Delete Record ");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you wish to delete the record?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            stockList.remove(selectedStockIndex);
            obsStockList.clear();
            obsStockList.addAll(stockList);

            lstView.setItems(obsStockList);
            lstView.getSelectionModel().select(0);
            displayRecord(obsStockList.get(0));

            stockList.writeToFile(file);
        }

    }

    public void exit() throws FileNotFoundException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit Program");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you wish to exit?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            //Have the CookieInventoryFile object write all of its CookieInventoryItem 
            //objects to the cookies.txt file. Overwrite the file, don't append to it. 

            stockList.writeToFile(file);
            System.exit(0);
        }
    }

    private static void dataEntryError() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Data Entry Error");
        alert.setHeaderText(null);
        alert.setContentText("Please enter the correct number.");
        Optional<ButtonType> result = alert.showAndWait();
    }

    private static void validDataError() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Data Entry Error");
        alert.setHeaderText(null);
        alert.setContentText("You must enter a valid numeric value.");
        Optional<ButtonType> result = alert.showAndWait();
    }

    private static void zeroDataError() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Data Entry Error");
        alert.setHeaderText(null);
        alert.setContentText("You must enter a value greater than 0.");
        Optional<ButtonType> result = alert.showAndWait();
    }

    private static void updated() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Data Updated");
        alert.setHeaderText(null);
        alert.setContentText("Your data was updated successfully.");
        Optional<ButtonType> result = alert.showAndWait();
    }

    private boolean isValidDouble(String string) {

        boolean numeric = true;
        try {
            Double num = Double.parseDouble(string);
        } catch (NumberFormatException e) {
            numeric = false;
        }
        return numeric;
    }

    private boolean validInput() {
        boolean valid = false;
        if (txtPE.getText().trim().isEmpty()) {
            dataEntryError();
            txtPE.requestFocus();
        }
        if (txtPB.getText().trim().isEmpty()) {
            dataEntryError();
            txtPB.requestFocus();
        }
        if (txtGRate.getText().trim().isEmpty()) {
            dataEntryError();
            txtGRate.requestFocus();
        } else if (!isValidDouble(txtPE.getText().trim())) {
            validDataError();
            txtPE.requestFocus();
        } else if (!isValidDouble(txtPB.getText().trim())) {
            validDataError();
            txtPB.requestFocus();
        } else if (!isValidDouble(txtGRate.getText().trim())) {
            validDataError();
            txtGRate.requestFocus();
        } else if (Double.parseDouble(txtPE.getText().trim()) <= 0) {
            zeroDataError();
            txtPE.requestFocus();
        } else if (Double.parseDouble(txtPB.getText().trim()) <= 0) {
            zeroDataError();
            txtPB.requestFocus();
        } else if (Double.parseDouble(txtGRate.getText().trim()) <= 0) {
            zeroDataError();
            txtGRate.requestFocus();
        }
        valid = true;
        return valid;
    }
    
    int selectedSearchIndex;
    String selectedSymbol;
    @FXML
    public void doSearch() {
        lstResult.getItems().clear();
        StockList tempList;
        //create a obs list
        ObservableList<Stock> obsSearchList = FXCollections.observableArrayList();
        //if selcted name then
        if (rbtName.isSelected()) {
            tempList = stockList.findStockByName(txtSearch.getText().trim());
        } else {
            //else search by symbol
            tempList = stockList.findStockBySymbol(txtSearch.getText().trim());
        }
        
        //add the stock list to the obs list
        obsSearchList.addAll(tempList);
        //binding tblview with the obs list
        lstResult.setItems(obsSearchList);
        //set default selected item to first one
        lstResult.getSelectionModel().select(0);
        
        //add a event listener
        lstResult.getSelectionModel().selectedItemProperty().addListener(new InvalidationListener() {

            @Override
            public void invalidated(Observable observable) {
                //this index is for the temp stocklist, not for the main stocklist
                selectedSearchIndex = lstResult.getSelectionModel().getSelectedIndex();
                selectedSymbol=lstResult.getSelectionModel().getSelectedItem().getSymbol();
            }
        });
    }

    //select a record in the tableview,swap back to main screen and show the 
    //selected record
    @FXML
    public void select() {
        int sIndex = stockList.indexOf(stockList.find(selectedSymbol));
        
        swap();
        
        lstView.getSelectionModel().select(sIndex);
        displayRecord(stockList.get(sIndex));
        
    }
}
