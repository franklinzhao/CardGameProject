package stocksmanager;

import java.util.HashMap;


/**
 *
 * @author franklinzhao
 */
public enum Sector {
    COMMUNICATION(1, "Communication Service"),
    CONSUMER_DISCRETIONARY(2, "Consumer Discretionary"),
    CONSUMER_STAPLES(3, "Consumer Staples"),
    ENERGY(4, "Energy"),
    FINANCIALS(5, "Financials"),
    HEALTHCARE(6, "Health Care"),
    INDUSTRIALS(7, "Industrials"),
    IT(8, "Information Technology"),
    MATERIALS(9, "Materials"),
    REALESTATE(10, "Real Estate"),
    UTILITIES(11, "Utilities");
    
    private int id;
    private String name;
    private static HashMap<String, Sector> lookUpByName = null;
    

    /**
     * The private constructor for the enum
     * @param id
     * @param name 
     */
    private Sector(int id, String name) {
        this.id = id;
        this.name = name;

    }
    
    private static void initNameLookUp() {
        lookUpByName = new HashMap<String,Sector>();
        for (Sector s : Sector.values()) {
            lookUpByName.put(s.name, s);
        }
    }
    
    /**
     *  reverse lookup the Rps by name
     * @param name
     * @return
     */
    public static Sector getSectorByFullName(String name) {
        if (lookUpByName == null) {
            initNameLookUp();
        }
        Sector s = lookUpByName.get(name);
        if (s == null) {
            throw new IllegalArgumentException("Invalid Sector name.");
        }
        return s;
    }
    
    public static Sector getSectorName(String name){
        
        return Sector.valueOf(name);
    }
    /**
     * 
     * @return the id of the sector
     */
    public int getId() {
        return id;
    }
    /**
     * 
     * @return the full name of the sector
     */
    public String getName() {
        return name;
    }

    
}
